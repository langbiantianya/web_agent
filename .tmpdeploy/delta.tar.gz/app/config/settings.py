"""应用配置（pydantic-settings，全部可由环境变量 / .env 覆盖）。"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # ---- 基础 ----
    app_name: str = "web-agent"
    debug: bool = False

    # ---- 数据库 ----
    # 三种方言都支持，靠 DATABASE_URL 里的驱动名区分：
    #   MySQL      mysql+asyncmy://user:pass@127.0.0.1:3306/agentdb?charset=utf8mb4
    #   PostgreSQL postgresql+psycopg://user:pass@127.0.0.1:5432/agentdb
    #   SQLite     sqlite+aiosqlite:///./web_agent.db（仅开发）
    database_url: str = "sqlite+aiosqlite:///./web_agent.db"
    db_pool_size: int = 10
    db_max_overflow: int = 20
    db_pool_recycle: int = 1800
    db_echo: bool = False
    # PostgreSQL 的**会话时区**。PG 的 ``now()`` 返回带时区的时间，落到
    # ``TIMESTAMP``（无时区）列时按**会话时区**折算——不钉成 UTC，中国本机写的
    # 时间戳会整整差 8 小时。它通过 libpq 的 ``options`` 启动参数下发：那是
    # **连接建立时**生效的，不受事务回滚影响（PG 里裸 ``SET`` 是事务性的，
    # ROLLBACK 会把它撤销，见 app/config/db.py 的说明）。
    # 置空则不下发该参数（自己保证服务器时区是 UTC 时才需要）。
    db_pg_timezone: str = "UTC"

    # ---- 安全 ----
    # 用于 api_key 的 Fernet 加解密 + SSE ticket 签发。
    # 生产环境必须通过环境变量 SECRET_KEY 覆盖（可用 `python -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())"` 生成）。
    secret_key: str = "dev-insecure-secret-key-change-me-in-production-0123456789"
    sse_ticket_ttl: int = 60  # 秒。设计文档 §5.1 写 5 分钟，§8 表格写 60s，此处取更严格的 60s。
    # 请求体上限（字节）。超了直接 413。
    # 没有这道限制时，一条 5 MB 的 system_prompt 会被完整受理——进内存、落库、
    # 送 LLM。成本不在这一次请求上，而在它后面那次模型调用上。
    # 2 MB 对本服务的 JSON 接口足够宽松（提示词与配置都远小于此）。
    max_request_bytes: int = 2 * 1024 * 1024

    # ---- 终端用户 OAuth / 会话（V4.6）----
    # 用户接口始终要求服务端会话。客户端提交的 user_id 不参与身份判断。
    auth_default_tenant: str = "default"
    user_session_cookie_secure: bool = True
    user_session_idle_minutes: int = 30
    user_session_absolute_hours: int = 12
    oauth_state_ttl_seconds: int = 600
    oauth_request_timeout_seconds: float = 10.0
    # 固定回调根地址可避免 Host 头参与 redirect_uri。为空时仅适合本地开发。
    oauth_public_base_url: str = ""
    # 浏览器跨源写请求允许的 Origin；为空表示只允许同源。
    auth_allowed_origins: list[str] = []
    # 测试或内网 IdP 可以显式放行；生产保持 false，防 SSRF。
    oauth_allow_private_networks: bool = False

    # ---- OAuth 登录限频与登录事务清理（V4.10 加固）----
    #
    # 登录链路原先是**裸**的：start / callback 都没有限频，攻击者可以无限次
    # 拉起 authorization-code 流程去撞库或打 IdP。下面三个参数是两道闸：
    #   * start 闸：限制单个 IP 在窗口内能拉起多少次登录事务；
    #   * callback 闸：限制单个 IP 在窗口内能失败多少次。
    # 两道闸都按「IP × 供应商」计数，互不影响。
    oauth_login_rate_limit_enabled: bool = True
    oauth_start_rate_limit_max: int = 10
    oauth_start_rate_limit_window_sec: int = 300
    oauth_callback_failure_limit_max: int = 10
    oauth_callback_failure_limit_window_sec: int = 900
    # 是否信任 X-Forwarded-For 取真实客户端 IP。**默认 false**：这个头由客户端
    # 自由填写，认它等于让攻击者自己挑限频的分组键。只有确定前面有可信反代
    # 并且反代会覆盖该头时才打开。
    oauth_trusted_proxy_headers: bool = False
    # 登录事务（oauth_login_attempt）的保留期与清理周期。过期行必须删，
    # 否则这张表只增不减——它同时也是限频的计数来源。
    oauth_attempt_retention_days: int = 7
    oauth_attempt_cleanup_enabled: bool = True
    oauth_attempt_cleanup_interval_sec: float = 3600.0
    oauth_attempt_cleanup_scan_limit: int = 1000
    # provider 故障监控：窗口内失败率超过阈值且失败数达到下限时告警。
    oauth_provider_failure_alert_window_sec: int = 900
    oauth_provider_failure_alert_ratio: float = 0.5
    oauth_provider_failure_alert_min_count: int = 5
    # ---- 独立 admin-web（V4.7）----
    admin_database_url: str = ""
    admin_public_base_url: str = ""
    admin_session_cookie_secure: bool = True
    admin_session_idle_minutes: int = 30
    admin_session_absolute_hours: int = 12
    admin_ui_default_theme: str = "fluent"
    super_admin_rotation_days: int = 30
    super_admin_rotation_grace_hours: int = 24
    super_admin_reset_cooldown_seconds: int = 600
    super_admin_password_notify_timeout_seconds: float = 15.0

    # 通知渠道只从环境变量读取；空值表示未启用。
    mail_enabled: bool = False
    mail_provider: str = "smtp"
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_use_tls: bool = True

    sms_enabled: bool = False
    sms_provider: str = ""
    aliyun_sms_access_key_id: str = ""
    aliyun_sms_access_key_secret: str = ""
    aliyun_sms_sign_name: str = ""
    aliyun_sms_template_code: str = ""
    aliyun_sms_region: str = "cn-hangzhou"
    tencent_sms_secret_id: str = ""
    tencent_sms_secret_key: str = ""
    tencent_sms_sdk_app_id: str = ""
    tencent_sms_sign_name: str = ""
    tencent_sms_template_id: str = ""
    tencent_sms_region: str = "ap-guangzhou"

    casbin_policy_refresh_seconds: float = 2.0

    # ---- 事件流 ----
    event_batch_size: int = 20       # 累积多少条 flush 一次（设计 §4.5）
    event_flush_interval: float = 0.05  # 或每 50ms flush 一次
    sse_ping_interval: int = 15      # 心跳间隔秒数（设计 §5.1）
    sse_replay_gap_threshold: int = 500  # 回放缺口超过该值视为事件已归档
    # 实时流空闲多久后回查一次 run 状态。兜住「重连时 run 刚好结束、事件还在
    # 批量队列里没落库」这种窗口——没有它，连接会一直等下去。
    sse_idle_recheck: float = 2.0

    # ---- 编排 ----
    context_max_tokens: int = 6000   # 上下文装配预算（设计 §4.4）
    context_max_messages: int = 50
    node_max_retries: int = 2        # 失败重试次数，指数退避（设计 §3.3）
    node_retry_base_delay: float = 0.5

    # ---- 工具调用（V3.2）----
    # 一次节点执行里「模型→工具→模型」最多来回几轮。超了就判定模型在工具上
    # 陷住了，直接失败——继续下去只会白烧 token，而重试同一个节点大概率还是
    # 同样地陷住。
    tool_max_rounds: int = 5
    # 工具结果回灌给模型时的最大字符数：太长会挤爆下一轮的 prompt。
    tool_result_max_chars: int = 4000
    # ---- 工具审计（V4.3）----
    # 每次工具执行单独提交一条脱敏账本，不参与节点事务。关闭后不再产生新记录，
    # 已有记录仍可由管理员查询到保留期结束。
    tool_audit_enabled: bool = True
    # 审计正文与模型回灌上限分开：模型仍只看到精简结果，管理员可回看更多原文。
    tool_audit_max_result_chars: int = 65536
    tool_audit_retention_days: int = 30
    tool_audit_cleanup_enabled: bool = True
    tool_audit_cleanup_interval_sec: float = 3600.0
    # 单次最多删除多少条过期记录，限制小内存机器上的瞬时开销。
    tool_audit_cleanup_scan_limit: int = 1000

    # ---- MCP（V4，§21）----
    # **stdio 的命令白名单前缀**。为空 = 禁止注册 stdio 类型的 MCP 服务器
    # （fail-closed）：注册一台 stdio 服务器就是「允许执行某个程序」，默认开着
    # 等于没有门（§21.10 第 ① 条）。
    # 环境变量写法：MCP_ALLOWED_COMMAND_PREFIXES='["/usr/bin/","/opt/tools/"]'
    mcp_allowed_command_prefixes: list[str] = []
    # **出网主机白名单**。为空 = 允许任意主机（但私网网段仍然默认拒绝）。
    mcp_allowed_hosts: list[str] = []
    # 是否放行私网 / 回环 / 链路本地地址。默认 False —— Streamable HTTP 的 URL
    # 来自配置，是 SSRF 面（§21.10 第 ② 条）。
    mcp_allow_private_networks: bool = False
    # 连接空闲多久后主动关闭。stdio 子进程必须回收，否则会攒出一堆僵尸进程。
    mcp_idle_timeout_sec: int = 300
    # 周期巡检间隔。不能只依赖调用时清理：没有新调用时，旧子进程也应该被回收。
    mcp_idle_sweep_interval_sec: float = 30.0
    # 单台服务器的并发调用上限（信号量）。避免把远端打爆。
    mcp_max_concurrency: int = 4
    # 连接失败时的重试次数（指数退避）。
    mcp_max_retries: int = 3

    # ---- 技能（V4，§22.6）----    # 技能正文进提示词的总字符预算。超出预算的技能**整个不注入**（宁少勿半）。
    skill_prompt_budget: int = 4000
    # 一次最多注入几个技能。
    skill_max_count: int = 5
    # 技能上传（导入 zip / 上传资源）的请求体上限。**只对有效后台 Session 且
    # 具备 skill.write 权限的
    # 请求生效**——没有有效权限的调用方仍受 max_request_bytes 约束，
    # 免得加个功能就把未认证流量能撑的缓冲口放大了。
    # 8 MB 压缩后的技能包解压后能到 50 MB（见 skill_import 的上限）。
    skill_upload_max_bytes: int = 8 * 1024 * 1024

    # ---- studio 脚本执行（V4，§22.8.8）----
    # studio 的 gRPC 地址（如 ``studio:9000``）。
    # **为空 = 未启用脚本执行**：这时 ``skill_exec`` 工具根本不注册，配置期直接拒。
    # 注意它与「配置了但连不上」是**两件事**：后者在 ``studio_exec_required``
    # 为真时会让服务**启动失败**（§22.8.6）。
    studio_exec_addr: str = ""
    # studio 连不上时是否启动失败。默认 true——studio 是部署的一个组成部分，
    # 它挂了说明部署不完整，让问题在部署时暴露，而不是在用户的一次 run 里暴露。
    # 本地开发可以显式设 false。
    studio_exec_required: bool = True
    # 单次执行的默认时限（毫秒）。
    studio_exec_timeout_ms: int = 30000
    # 模型能请求的时限**上限**（毫秒）。写死在配置里，模型改不了。
    studio_exec_max_timeout_ms: int = 60000
    # 脚本正文长度上限（字符）。
    studio_exec_max_script_chars: int = 200000
    # gRPC 的负载均衡策略。默认 ``round_robin``：当一个 DNS 名字解析到多个后端时，
    # 请求会轮询到这些地址；``pick_first`` 会一直使用第一个解析结果
    # （skill-service §13.4）。排查问题时可以临时改成 ``pick_first``。
    studio_exec_lb_policy: str = "round_robin"
    # studio 的最低版本。默认 1.0.0：fast-only 部署不该被 2.0.0 的语义变更卡住。
    # 只有「声明了 isolated 的技能」才另外要求 >= 2.0.0 且上报 profiles[isolated]。
    studio_exec_min_version: str = "1.0.0"
    # 能力缓存（Health）的 TTL（秒）。studio 滚动升级后镜像/档位可能变化，
    # 一直用启动时那份会误判；调用 isolated 前会按这个 TTL 刷新。
    # 0 表示每次都刷新（测试用）。
    studio_exec_health_ttl_sec: float = 30.0

    # ---- LLM ----
    openai_timeout: float = 120.0

    # ---- 演示/种子数据用的模型（scripts/seed.py 读取）----
    # 统一走 OpenAI 兼容协议，换供应商只改这三个值，不动代码。
    minimax_base_url: str = "https://api.minimaxi.com/v1"
    minimax_model: str = "MiniMax-M2.7"
    minimax_api_key: str = ""

    # ---- 事件归档 ----
    run_event_retention_days: int = 7  # 设计 §4.2 清理策略

    # ---- 审批暂停点（V3.1）----
    # LangGraph checkpointer 存的是「图暂停在哪、状态是什么」，**不存对外事件**
    # ——事件仍然只由 run_event + Redis Stream 负责，两者不冲突。
    # 开了 Redis 就用 Redis saver（多实例共享同一个暂停点），否则用本地 SQLite
    # 文件（单实例开发够用，且不引入新的外部依赖）。
    checkpoint_enabled: bool = True
    # 单实例开发用的本地 SQLite 文件路径。**相对路径按项目根解析**（不是按进程
    # 工作目录）——否则用不同的 WORKDIR 启动两个实例会各写各的 checkpoints.db，
    # 审批暂停点互不可见，run 就永远卡在 waiting。与下面的 sensitive_model_path
    # 同一个口径。
    checkpoint_sqlite_path: str = "./checkpoints.db"
    # 周期清理崩溃后遗留的 checkpoint。正常终态会立即删除；这里兜住进程在
    # 删除前被硬杀、或数据库里已经找不到对应 run 的孤儿 thread。
    checkpoint_cleanup_enabled: bool = True
    checkpoint_cleanup_interval_sec: float = 300.0
    # 找不到对应 run 的 thread 至少保留这么久，避免刚创建、DB 尚未提交的
    # checkpoint 被误删。终态 run 的 thread 不受这个宽限期影响。
    checkpoint_orphan_retention_sec: int = 86400
    # 单次最多扫描多少条 checkpoint 记录，限制小内存机器上的瞬时开销。
    checkpoint_cleanup_scan_limit: int = 1000
    # 审批决策的等待上限（秒）。**当前未启用**（设计文档 §16.10）：超时算通过
    # 还是算驳回尚未定，语义没定就不能自动收尾——那等于替审批人做决定。
    # 保留这一项是为了把「将来启用时需要什么」写下来，不是说它现在生效。
    approval_timeout: int = 86400
    # 超时巡检周期；多个实例同时扫描也安全，审批行使用条件更新竞争收口。
    approval_timeout_scan_interval: float = 30.0

    # ---- Redis（V2 多实例）----
    # 关：走进程内总线 + MySQL 回放（V1 单实例行为，现有测试全部依赖它）。
    # 开：事件走 Redis Stream（回放源）与 Pub/Sub（实时），可多实例水平扩容。
    #     开启后**没有降级路径**——Redis 不可用时服务直接启动失败。这是刻意的：
    #     静默退回进程内总线会造成「看起来能跑、实际跨实例收不到事件」的分裂大脑，
    #     比启动失败难查得多。单实例开发请显式关掉本项。
    redis_enabled: bool = False
    redis_url: str = "redis://192.168.1.5:6379/0"
    # 所有键与频道的统一前缀。多套环境共享同一个 Redis 时用它做隔离。
    redis_key_prefix: str = "webagent"
    # 每个 run 的事件 Stream 保留条数上限（近似裁剪）。Stream 是**回放源**，
    # 长期归档仍在 MySQL，所以只需保留够覆盖「断线重连 + 事件清理周期」的量。
    redis_stream_maxlen: int = 20000
    # run 活动标记的 TTL（秒）。生成方需周期性续期；TTL 到期即视为该 run 已无主，
    # 启动恢复据此判断「能不能把这条 running run 标成 error」。
    redis_activity_ttl: int = 120
    # Redis 订阅的轮询间隔（秒）。刻意与 ``sse_idle_recheck`` 分开：后者是 SSE
    # 「队列空了要不要回查 run 状态」的兜底周期，和订阅任务的收尾速度无关。
    # 退订时只置停止标志、让订阅任务在下一个周期自行退出（直接 cancel 会打断
    # 正在进行的 Redis 读，让连接锁状态不一致，后续关闭操作会永久挂起），
    # 所以这个值直接决定退订的快慢，1 秒是个平衡点。
    redis_poll_interval: float = 1.0
    # 单次 Redis 读写的**超时**（秒）。刻意与 ``socket_connect_timeout`` 分开：
    # 建连超时只管「连不连得上」，连上之后的读**默认没有上限**——对端只要不
    # 回包，这条协程就永远挂着。实测踩过：Redis 所在网段抖动时，XADD / PUBLISH
    # 里的一个读把整个生成流程冻住，外部看就是「服务不响应了」。
    # 5 秒对局域网里的 Redis 绰绰有余，而挂死的代价高得多。
    # 注意不影响 Pub/Sub：``get_message(timeout=...)`` 自己带超时，
    # ``parse_response(block=True)`` 显式传 ``math.inf``，都不受这个值影响。
    redis_socket_timeout: float = 5.0

    # ---- 敏感词前置过滤（V3.4）----
    # 总开关，默认开。这是「提示词进 LLM 之前」的那道前置，关掉它等于没有。
    # 显式关掉是有记录、可审计的：配置里留痕，启动日志里也有一行说明。
    sensitive_enabled: bool = True
    # 判定阈值。留 0 表示用**模型自带**的推荐阈值——那是训练时按「误报率不超过
    # 目标」挑出来的，比手填一个数靠谱。显式给值则覆盖它：调高更严（漏得多），
    # 调低更松（误杀多）。
    sensitive_threshold: float = 0.0
    # 模型文件路径。默认指向仓库里那份，路径按**项目根**解析而不是相对工作
    # 目录——服务从哪个目录启动都能找到模型，少一类「本地能跑、部署找不到」。
    sensitive_model_path: str = str(
        Path(__file__).resolve().parents[2] / "app" / "core" / "sensitive_model.npz"
    )
    # 滑窗参数。0 表示用模型 meta 里记录的值。重训换了窗口，推理必须跟着换，
    # 所以默认值来自模型而不是写死在代码里；这两项只给「临时调参、不重训」用。
    sensitive_window: int = 0
    sensitive_stride: int = 0
    # 单条提示词最多扫描多少字符。超长的只扫前面这段——敏感内容几乎总在开头，
    # 而这一步是为了**控住资源占用**。
    sensitive_max_chars: int = 4000


@lru_cache
def get_settings() -> Settings:
    """构造并缓存唯一的 Settings 实例。

    ``lru_cache`` 保证全进程只读一次 .env/环境变量：既避免每次 import/调用
    重解析，也避免测试里改环境变量后出现「两份配置」。要改配置请改环境变量
    并重启进程，而不是指望重新调用本函数。
    """
    return Settings()


settings = get_settings()

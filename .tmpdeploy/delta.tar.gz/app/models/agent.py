"""agent 表 —— Agent 配置（设计文档 §4.2）。"""

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import JSON_COL, PK, Base


class Agent(Base):
    __tablename__ = "agent"

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(sa.String(64), nullable=False, unique=True)
    tenant_id: Mapped[str] = mapped_column(
        sa.String(64), nullable=False, default="default"
    )
    name: Mapped[str] = mapped_column(sa.String(128), nullable=False)
    description: Mapped[str] = mapped_column(sa.String(512), default="")
    system_prompt: Mapped[str] = mapped_column(sa.Text, nullable=False)
    # 管理端新建的 Agent 选择一条已配置的 LLM 连接；地址与密钥由该连接统一
    # 维护。保留 model 作为 Agent 级模型选择，base_url/api_key_cipher 则只服务
    # 升级前的存量配置。
    llm_endpoint_code: Mapped[str | None] = mapped_column(
        sa.String(64), nullable=True
    )
    model: Mapped[str] = mapped_column(sa.String(128), nullable=False)
    base_url: Mapped[str] = mapped_column(sa.String(255), nullable=False)
    api_key_cipher: Mapped[str] = mapped_column(sa.String(512), nullable=False)
    temperature: Mapped[float] = mapped_column(sa.DECIMAL(3, 2), default=0.70)
    max_tokens: Mapped[int] = mapped_column(sa.Integer, default=2048)
    tools: Mapped[list | None] = mapped_column(JSON_COL, default=None)
    # 工具级策略：{tool_name: {"enabled": bool, "max_concurrency": int,
    # "timeout_sec": float}}。不在策略表里的工具沿用全局默认。
    tool_policy: Mapped[dict | None] = mapped_column(JSON_COL, default=None)
    # 绑定的技能 code 列表（V4，§22.5）。**不是**工具白名单：技能只贡献指令
    # 正文，模型能不能调工具仍然只看 tools。
    skills: Mapped[list | None] = mapped_column(JSON_COL, default=None)
    # 输出格式：``text``（默认，照常输出文本）或 ``json``（最终回答必须是
    # JSON）。json 模式由提示词层约束 + 服务端解析校验两道把关，**不改**
    # LLM 请求参数——``response_format={"type":"json_object"}`` 并非所有
    # OpenAI 兼容端点都认（MiniMax 与部分自建端点会直接 400）。
    response_format: Mapped[str] = mapped_column(
        sa.String(16), nullable=False, default="text"
    )
    # JSON 模式下的结构要求（JSON Schema 对象）。为空表示「只要求是 JSON，
    # 不限定结构」。
    response_schema: Mapped[dict | None] = mapped_column(JSON_COL, default=None)
    extra_params: Mapped[dict | None] = mapped_column(JSON_COL, default=None)
    enabled: Mapped[bool] = mapped_column(sa.SmallInteger, default=1)
    version: Mapped[int] = mapped_column(sa.Integer, default=1)
    created_at: Mapped[object] = mapped_column(
        sa.DateTime, server_default=sa.func.now(), nullable=False
    )
    updated_at: Mapped[object] = mapped_column(
        sa.DateTime,
        server_default=sa.func.now(),
        onupdate=sa.func.now(),
        nullable=False,
    )

    __table_args__ = (
        sa.Index("idx_agent_enabled", "enabled"),
        sa.Index("idx_agent_tenant", "tenant_id"),
        sa.Index("idx_agent_llm_endpoint", "llm_endpoint_code"),
    )

    def __repr__(self) -> str:  # pragma: no cover
        """调试用摘要。刻意只显示 code 与 version，不含 api_key_cipher。"""
        return f"<Agent {self.code} v{self.version}>"
